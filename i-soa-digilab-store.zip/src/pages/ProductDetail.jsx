import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import TypeBadge from '../components/TypeBadge'
import Logo from '../components/Logo'
import { getProductBySlug, recordView } from '../lib/api'

export default function ProductDetail() {
  const { slug } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeShot, setActiveShot] = useState(0)

  useEffect(() => {
    setLoading(true)
    recordView(slug)
    getProductBySlug(slug)
      .then(setProduct)
      .catch(() => setProduct(null))
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug])

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl animate-pulse px-4 py-16">
        <div className="h-8 w-1/3 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="mt-6 h-96 rounded-2xl bg-slate-200 dark:bg-slate-800" />
      </div>
    )
  }

  if (!product) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-5xl">🤖</p>
        <h1 className="mt-4 font-display text-2xl font-bold">Produit introuvable</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">Ce produit n’existe pas ou n’est pas publié.</p>
        <Link to="/" className="btn-primary mt-6">← Retour à l’accueil</Link>
      </div>
    )
  }

  const screens = product.screenshots || []

  const accessLinks = []
  if (product.site_url) accessLinks.push({ label: 'Ouvrir le site', href: product.site_url })
  if (product.apk_url) accessLinks.push({ label: "Télécharger l'APK", href: product.apk_url })
  const hasSite = product.type === 'site' || product.type === 'app_site'
  const hasApk = product.type === 'app' || product.type === 'app_site'

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <nav className="text-sm text-slate-500 dark:text-slate-400">
        <Link to="/" className="hover:text-brand-500">Accueil</Link>
        <span className="mx-2">/</span>
        <span className="text-slate-700 dark:text-slate-200">{product.name}</span>
      </nav>

      {/* Header */}
      <div className="mt-6 flex flex-col gap-6 md:flex-row md:items-start">
        {product.icon_url ? (
          <img src={product.icon_url} alt="" className="h-20 w-20 shrink-0 rounded-2xl shadow-soft-lg" />
        ) : (
          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-brand-500 text-2xl font-bold text-white">
            {product.name?.[0]}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <TypeBadge type={product.type} />
            {product.category && (
              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                {product.category}
              </span>
            )}
          </div>
          <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight text-slate-900 md:text-4xl dark:text-white">
            {product.name}
          </h1>
          <p className="mt-3 text-lg text-slate-600 dark:text-slate-300">{product.short_description}</p>

          <div className="mt-5 flex flex-wrap gap-3">
            {accessLinks.map((l) => (
              <a key={l.label} href={l.href} target="_blank" rel="noreferrer" className="btn-primary">
                {l.label} <span aria-hidden>↗</span>
              </a>
            ))}
            {accessLinks.length === 0 && (
              <span className="inline-flex items-center rounded-xl bg-slate-100 px-4 py-2.5 text-sm font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                Liens d’accès bientôt disponibles
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-3">
        {/* Left / main column */}
        <div className="lg:col-span-2">
          {/* Gallery */}
          {screens.length > 0 && (
            <div>
              <div className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 dark:border-slate-800">
                <img
                  src={screens[activeShot]}
                  alt={`Capture ${activeShot + 1}`}
                  className="aspect-video w-full object-cover"
                />
              </div>
              <div className="mt-3 grid grid-cols-3 gap-3">
                {screens.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveShot(i)}
                    className={`overflow-hidden rounded-xl border-2 transition ${
                      i === activeShot
                        ? 'border-brand-500'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={s} alt="" className="aspect-video w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Demo video */}
          {product.demo_video_url && (
            <div className="mt-8">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">Vidéo de démonstration</h2>
              <div className="mt-3 overflow-hidden rounded-2xl border border-slate-200 bg-black dark:border-slate-800">
                <video src={product.demo_video_url} controls className="aspect-video w-full" />
              </div>
            </div>
          )}

          {/* Description */}
          <div className="mt-8">
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">Description</h2>
            <div className="mt-3 space-y-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              {(product.long_description || '').split('\n').filter(Boolean).map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </div>

          {/* Features */}
          {product.features?.length > 0 && (
            <div className="mt-8">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">Fonctionnalités clés</h2>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {product.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-100 text-brand-600 dark:bg-brand-900 dark:text-brand-300">✓</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Changelog */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">Nouveautés</h2>
            {product.changelog?.length > 0 ? (
              <div className="mt-4 space-y-4">
                {product.changelog.map((c) => (
                  <div key={c.id} className="relative pl-5">
                    <span className="absolute left-0 top-1.5 h-2 w-2 rounded-full bg-brand-500" />
                    <span className="absolute left-1 top-3 bottom-0 w-px bg-slate-200 dark:bg-slate-700" />
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-brand-50 px-2 py-0.5 text-xs font-bold text-brand-600 dark:bg-brand-950 dark:text-brand-300">
                        v{c.version}
                      </span>
                      <span className="text-xs text-slate-400">{c.released_at}</span>
                    </div>
                    <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{c.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">
                Aucune note de version pour l’instant.
              </p>
            )}
          </div>

          {/* Developer block */}
          <div className="rounded-2xl border border-slate-200 bg-gradient-to-b from-brand-50 to-white p-5 dark:border-slate-800 dark:from-brand-950/40 dark:to-slate-900">
            <div className="flex items-center gap-3">
              <Logo size={40} />
              <div>
                <p className="text-xs uppercase tracking-wide text-slate-400">Développé par</p>
                <p className="font-display text-lg font-bold text-slate-900 dark:text-white">i-SOA DigiLab</p>
              </div>
            </div>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">
              La branche Recherche &amp; Développement du groupe i-SOAMADA.
            </p>
            <Link to="/a-propos" className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 hover:text-brand-500 dark:text-brand-400">
              En savoir plus <span aria-hidden>→</span>
            </Link>
          </div>

          {/* Meta */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 text-sm dark:border-slate-800 dark:bg-slate-900">
            <dl className="space-y-2">
              <div className="flex justify-between"><dt className="text-slate-500 dark:text-slate-400">Type</dt><dd className="font-medium text-slate-700 dark:text-slate-200">{product.type}</dd></div>
              {hasSite && <div className="flex justify-between"><dt className="text-slate-500 dark:text-slate-400">Accès</dt><dd className="font-medium text-slate-700 dark:text-slate-200">Site Web</dd></div>}
              {hasApk && <div className="flex justify-between"><dt className="text-slate-500 dark:text-slate-400">Mobile</dt><dd className="font-medium text-slate-700 dark:text-slate-200">Application (APK)</dd></div>}
              <div className="flex justify-between"><dt className="text-slate-500 dark:text-slate-400">Statut</dt><dd className="font-medium text-emerald-600">Publié</dd></div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  )
}
