import { useEffect, useState } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { supabase, IS_SUPABASE_CONFIGURED, ALLOWED_ADMIN_EMAIL } from '../../lib/supabaseClient'
import { isAdminEmail, getSession } from '../../lib/api'

/**
 * Guards the admin area.
 *
 * SUPABASE MODE : reads the real Supabase Auth session (Google OAuth only) and
 * verifies auth.email() === ALLOWED_ADMIN_EMAIL. A non-authorized Google account
 * is blocked here (and additionally blocked server-side by RLS policies below).
 *
 * DEMO MODE : checks the simulated session.
 */
export default function RequireAdmin({ children }) {
  const location = useLocation()
  const [state, setState] = useState({ loading: true, ok: false, reason: '' })

  useEffect(() => {
    let active = true
    async function check() {
      let email = null
      if (IS_SUPABASE_CONFIGURED) {
        const { data } = await supabase.auth.getSession()
        email = data?.session?.user?.email || null
      } else {
        email = getSession()?.email || null
      }
      const ok = isAdminEmail(email)
      if (active) {
        setState({
          loading: false,
          ok,
          reason: email ? (ok ? '' : `Compte ${email} non autorisé`) : 'Aucun compte connecté',
        })
      }
    }
    check()
    return () => {
      active = false
    }
  }, [])

  if (state.loading) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-24 text-center">
        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
        <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">Vérification de l’accès…</p>
      </div>
    )
  }

  if (!state.ok) {
    return (
      <Navigate to="/admin/login" replace state={{ from: location, reason: state.reason }} />
    )
  }

  return children
}
