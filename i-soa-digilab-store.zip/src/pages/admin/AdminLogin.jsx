import { useState } from 'react'
import { useLocation, useNavigate, Link } from 'react-router-dom'
import Logo from '../../components/Logo'
import { signInWithGoogle } from '../../lib/api'
import { ALLOWED_ADMIN_EMAIL, IS_SUPABASE_CONFIGURED } from '../../lib/supabaseClient'

export default function AdminLogin() {
  const navigate = useNavigate()
  const location = useLocation()
  const reason = location.state?.reason
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function onGoogle() {
    setBusy(true)
    setError('')
    try {
      const res = await signInWithGoogle()
      if (res && res.needsRedirect) {
        // Supabase OAuth redirect already started; nothing else to do.
        return
      }
      navigate('/admin')
    } catch (e) {
      setError(e.message || 'Connexion impossible.')
      setBusy(false)
    }
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-soft-lg dark:border-slate-800 dark:bg-slate-900">
          <div className="flex justify-center">
            <Logo size={56} />
          </div>
          <h1 className="mt-4 text-center font-display text-2xl font-bold text-slate-900 dark:text-white">
            Espace admin
          </h1>
          <p className="mt-2 text-center text-sm text-slate-500 dark:text-slate-400">
            Accès réservé à <span className="font-semibold text-slate-700 dark:text-slate-200">i-SOA DigiLab</span>.
            Connexion via Google uniquement — aucune inscription publique.
          </p>

          {reason && (
            <p className="mt-4 rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-medium text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">
              {reason}
            </p>
          )}
          {error && (
            <p className="mt-4 rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-medium text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">
              {error}
            </p>
          )}

          <button
            onClick={onGoogle}
            disabled={busy}
            className="mt-6 flex w-full items-center justify-center gap-3 rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 disabled:opacity-60 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
          >
            <svg width="20" height="20" viewBox="0 0 48 48">
              <path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.1 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/>
              <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.1 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
              <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
              <path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.6l6.2 5.2C36.9 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z"/>
            </svg>
            Se connecter avec Google
          </button>

          <div className="mt-5 rounded-xl bg-slate-50 px-4 py-3 text-xs leading-relaxed text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            <p className="font-semibold text-slate-600 dark:text-slate-300">Compte autorisé uniquement :</p>
            <p className="mt-1 break-all font-mono">{ALLOWED_ADMIN_EMAIL}</p>
            <p className="mt-2">
              Tout autre compte Google est automatiquement refusé (vérification côté serveur via les
              règles de sécurité Supabase).
            </p>
            {!IS_SUPABASE_CONFIGURED && (
              <p className="mt-2 rounded-lg bg-amber-100 px-2 py-1 font-semibold text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
                Mode démo : la connexion est simulée pour l’aperçu. Ajoutez vos clés Supabase pour la
                vraie authentification Google OAuth.
              </p>
            )}
          </div>
        </div>
        <p className="mt-5 text-center text-sm text-slate-400">
          <Link to="/" className="hover:text-brand-500">← Retour à la vitrine</Link>
        </p>
      </div>
    </div>
  )
}
