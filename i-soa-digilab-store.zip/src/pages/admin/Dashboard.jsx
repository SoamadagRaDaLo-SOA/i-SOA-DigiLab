import { useEffect, useMemo, useState } from 'react'
import {
  getProducts,
  getMessages,
  deleteProduct,
  deleteMessage,
  setMessageStatus,
  getAboutContent,
  saveAboutContent,
  getViews,
} from '../../lib/api'
import { AdminShell, Card, Field } from './adminUi'
import ProductForm from './ProductForm'
import TypeBadge from '../../components/TypeBadge'

const TABS = [
  { key: 'stats', label: 'Tableau de bord' },
  { key: 'products', label: 'Produits' },
  { key: 'messages', label: 'Messages' },
  { key: 'about', label: 'Page À propos' },
]

export default function Dashboard() {
  const [tab, setTab] = useState('stats')
  const [products, setProducts] = useState([])
  const [messages, setMessages] = useState([])
  const [about, setAbout] = useState(null)
  const [views, setViews] = useState({})
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null) // null | 'new' | product
  const [formOpen, setFormOpen] = useState(false)
  const [aboutForm, setAboutForm] = useState(null)

  async function load() {
    const [p, m, a, v] = await Promise.all([
      getProducts({ includeDrafts: true }),
      getMessages(),
      getAboutContent(),
      Promise.resolve(getViews()),
    ])
    setProducts(p)
    setMessages(m)
    setAbout(a)
    setAboutForm(a)
    setViews(v)
    setLoading(false)
  }
  useEffect(() => { load() }, [])

  const unread = messages.filter((m) => m.status === 'new').length
  const published = products.filter((p) => p.status === 'published').length
  const drafts = products.filter((p) => p.status !== 'published').length

  const topViewed = useMemo(() => {
    return products
      .map((p) => ({ ...p, views: views[p.slug] || 0 }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 5)
  }, [products, views])

  async function onDeleteProduct(p) {
    if (!confirm(`Supprimer « ${p.name} » ?`)) return
    await deleteProduct(p.id)
    load()
  }
  async function markMsg(m, status) {
    await setMessageStatus(m.id, status)
    load()
  }
  async function onDeleteMsg(m) {
    if (!confirm('Supprimer ce message ?')) return
    await deleteMessage(m.id)
    load()
  }

  return (
    <AdminShell
      title="Espace admin i-SOA DigiLab"
      subtitle="Gérez votre catalogue, vos messages et votre contenu. Accès réservé."
    >
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3 dark:border-slate-800">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
              tab === t.key
                ? 'bg-brand-600 text-white shadow-soft'
                : 'text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
            }`}
          >
            {t.label}
            {t.key === 'messages' && unread > 0 && (
              <span className="ml-1.5 rounded-full bg-rose-500 px-1.5 py-0.5 text-[10px] font-bold text-white">{unread}</span>
            )}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="mt-6 animate-pulse space-y-4">
          <div className="h-32 rounded-2xl bg-slate-200 dark:bg-slate-800" />
          <div className="h-64 rounded-2xl bg-slate-200 dark:bg-slate-800" />
        </div>
      ) : (
        <>
          {/* ---------- STATS ---------- */}
          {tab === 'stats' && (
            <div className="mt-6 space-y-6">
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                <StatBox label="Produits au total" value={products.length} tone="text-brand-600" />
                <StatBox label="Publiés" value={published} tone="text-emerald-600" />
                <StatBox label="Brouillons / hors ligne" value={drafts} tone="text-amber-600" />
                <StatBox label="Messages reçus" value={messages.length} tone="text-indigo-600" extra={unread ? `${unread} non lu(s)` : ''} />
              </div>

              <Card title="Produits les plus consultés">
                {topViewed.length === 0 ? (
                  <p className="text-sm text-slate-500">Aucune donnée de consultation.</p>
                ) : (
                  <ul className="space-y-3">
                    {topViewed.map((p, i) => (
                      <li key={p.id} className="flex items-center gap-3">
                        <span className="w-6 text-center font-display text-lg font-bold text-slate-300">{i + 1}</span>
                        {p.icon_url ? (
                          <img src={p.icon_url} alt="" className="h-9 w-9 rounded-lg" />
                        ) : (
                          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-500 text-white">{p.name?.[0]}</span>
                        )}
                        <span className="flex-1 truncate text-sm font-medium text-slate-700 dark:text-slate-200">{p.name}</span>
                        <span className="text-xs text-slate-400">{p.views} vue{p.views > 1 ? 's' : ''}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>

              <Card title="Derniers messages">
                {messages.length === 0 ? (
                  <p className="text-sm text-slate-500">Aucun message pour l’instant.</p>
                ) : (
                  <ul className="space-y-3">
                    {messages.slice(0, 3).map((m) => (
                      <li key={m.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800">
                        <div className="min-w-0">
                          <p className="truncate font-medium text-slate-700 dark:text-slate-200">{m.name} <span className="text-slate-400">· {m.subject}</span></p>
                          <p className="truncate text-xs text-slate-400">{m.message}</p>
                        </div>
                        <StatusPill status={m.status} />
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            </div>
          )}

          {/* ---------- PRODUCTS ---------- */}
          {tab === 'products' && (
            <div className="mt-6">
              <div className="mb-4 flex justify-end">
                <button className="btn-primary" onClick={() => { setEditing(null); setFormOpen(true) }}>
                  + Ajouter un produit
                </button>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {products.map((p) => (
                  <div key={p.id} className="rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-slate-800 dark:bg-slate-900">
                    <div className="flex items-center gap-3 border-b border-slate-100 p-4 dark:border-slate-800">
                      {p.icon_url ? (
                        <img src={p.icon_url} alt="" className="h-12 w-12 rounded-xl" />
                      ) : (
                        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">{p.name?.[0]}</span>
                      )}
                      <div className="min-w-0">
                        <p className="truncate text-sm font-bold text-slate-800 dark:text-white">{p.name}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5">
                          <TypeBadge type={p.type} />
                          {p.is_featured && <span className="text-xs text-amber-500">★</span>}
                          <StatusPill status={p.status} />
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 p-3">
                      <button className="btn-ghost flex-1 text-xs" onClick={() => { setEditing(p); setFormOpen(true) }}>Modifier</button>
                      <button className="flex-1 rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 dark:border-rose-900 dark:text-rose-400 dark:hover:bg-rose-900/20" onClick={() => onDeleteProduct(p)}>Supprimer</button>
                    </div>
                  </div>
                ))}
              </div>
              {products.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500 dark:border-slate-700">
                  Aucun produit. Cliquez sur « Ajouter un produit ».
                </div>
              )}
            </div>
          )}

          {/* ---------- MESSAGES ---------- */}
          {tab === 'messages' && (
            <div className="mt-6 space-y-4">
              {messages.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500 dark:border-slate-700">
                  Aucun message reçu via le formulaire de contact.
                </div>
              )}
              {messages.map((m) => (
                <div key={m.id} className="rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-3.5 dark:border-slate-800">
                    <div className="flex items-center gap-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-600 dark:bg-brand-900 dark:text-brand-300">
                        {m.name?.[0]?.toUpperCase()}
                      </span>
                      <div>
                        <p className="text-sm font-bold text-slate-800 dark:text-white">{m.name}</p>
                        <p className="text-xs text-slate-400">{m.email} · {m.created_at?.slice(0, 10)}</p>
                      </div>
                    </div>
                    <StatusPill status={m.status} />
                  </div>
                  <div className="px-5 py-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{m.subject}</p>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{m.message}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 border-t border-slate-100 px-5 py-3 dark:border-slate-800">
                    <button className="btn-ghost text-xs" onClick={() => markMsg(m, 'read')}>Marquer lu</button>
                    <button className="btn-ghost text-xs" onClick={() => markMsg(m, 'handled')}>Marquer traité</button>
                    <a className="btn-ghost text-xs" href={`mailto:${m.email}?subject=Re: ${encodeURIComponent(m.subject)}`}>Répondre</a>
                    <button className="ml-auto rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:border-rose-900 dark:text-rose-400 dark:hover:bg-rose-900/20" onClick={() => onDeleteMsg(m)}>Supprimer</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ---------- ABOUT ---------- */}
          {tab === 'about' && aboutForm && (
            <div className="mt-6">
              <Card title="Contenu de la page À propos">
                <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
                  Modifiez le texte sans écrire de code. Il sera repris automatiquement sur la page publique « À propos ».
                </p>
                <div className="space-y-4">
                  <Field label="Introduction">
                    <textarea rows={3} value={aboutForm.intro} onChange={(e) => setAboutForm({ ...aboutForm, intro: e.target.value })} className="input resize-none" />
                  </Field>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Mission">
                      <textarea rows={3} value={aboutForm.mission} onChange={(e) => setAboutForm({ ...aboutForm, mission: e.target.value })} className="input resize-none" />
                    </Field>
                    <Field label="Vision">
                      <textarea rows={3} value={aboutForm.vision} onChange={(e) => setAboutForm({ ...aboutForm, vision: e.target.value })} className="input resize-none" />
                    </Field>
                  </div>
                  <Field label="Valeurs" hint="Une valeur par ligne.">
                    <textarea rows={3} value={(aboutForm.values || []).join('\n')} onChange={(e) => setAboutForm({ ...aboutForm, values: e.target.value.split('\n').filter(Boolean) })} className="input resize-none" />
                  </Field>
                  <button className="btn-primary" onClick={async () => { await saveAboutContent(aboutForm); alert('Contenu enregistré ✓'); }}>Enregistrer</button>
                </div>
              </Card>
            </div>
          )}
        </>
      )}

      <ProductForm open={formOpen} onClose={() => setFormOpen(false)} product={editing} onSaved={() => load()} />
    </AdminShell>
  )
}

function StatBox({ label, value, tone, extra }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
      <p className={`font-display text-3xl font-extrabold ${tone}`}>{value}</p>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{label}</p>
      {extra && <p className="mt-0.5 text-xs font-semibold text-rose-500">{extra}</p>}
    </div>
  )
}

function StatusPill({ status }) {
  const map = {
    new: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
    read: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    handled: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    published: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    draft: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
    archived: 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400',
  }
  const label = { new: 'Nouveau', read: 'Lu', handled: 'Traité', published: 'Publié', draft: 'Brouillon', archived: 'Archivé' }[status] || status
  return (
    <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${map[status] || map.draft}`}>{label}</span>
  )
}
