import { useEffect, useState } from 'react'
import { Card, Field, Modal } from './adminUi'
import { createProduct, updateProduct, saveChangelogEntry, deleteChangelogEntry } from '../../lib/api'

const TYPES = [
  { value: 'app', label: 'App' },
  { value: 'site', label: 'Site Web' },
  { value: 'app_site', label: 'App + Site' },
  { value: 'demo', label: 'Démo / Réalisation' },
]

const EMPTY = {
  name: '',
  slug: '',
  type: 'app',
  category: '',
  short_description: '',
  long_description: '',
  features: [],
  icon_url: '',
  screenshots: [],
  demo_video_url: '',
  site_url: '',
  apk_url: '',
  status: 'published',
  is_featured: false,
}

function readAsDataURL(file) {
  return new Promise((resolve) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result)
    r.readAsDataURL(file)
  })
}

export default function ProductForm({ open, onClose, product, onSaved }) {
  const [form, setForm] = useState(EMPTY)
  const [featuresText, setFeaturesText] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [changelog, setChangelog] = useState([])
  const [clVersion, setClVersion] = useState('')
  const [clDesc, setClDesc] = useState('')

  useEffect(() => {
    if (product) {
      setForm({
        name: product.name || '',
        slug: product.slug || '',
        type: product.type || 'app',
        category: product.category || '',
        short_description: product.short_description || '',
        long_description: product.long_description || '',
        features: product.features || [],
        icon_url: product.icon_url || '',
        screenshots: product.screenshots || [],
        demo_video_url: product.demo_video_url || '',
        site_url: product.site_url || '',
        apk_url: product.apk_url || '',
        status: product.status || 'published',
        is_featured: !!product.is_featured,
      })
      setFeaturesText((product.features || []).join('\n'))
      setChangelog(product.changelog || [])
    } else {
      setForm(EMPTY)
      setFeaturesText('')
      setChangelog([])
      setClVersion('')
      setClDesc('')
    }
    setError('')
  }, [product])

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))
  const slugify = (s) =>
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')

  async function handleIcon(e) {
    const file = e.target.files?.[0]
    if (file) {
      const url = await readAsDataURL(file)
      setForm((f) => ({ ...f, icon_url: url }))
    }
  }
  async function handleScreenshots(e) {
    const files = Array.from(e.target.files || [])
    const urls = []
    for (const f of files) urls.push(await readAsDataURL(f))
    setForm((f) => ({ ...f, screenshots: [...f.screenshots, ...urls].slice(0, 8) }))
  }

  async function onSubmit(e) {
    e.preventDefault()
    setError('')
    if (!form.name.trim()) return setError('Le nom est requis.')
    if (form.type !== 'demo' && !form.site_url && !form.apk_url) {
      // not fatal, just a hint
    }
    setSaving(true)
    try {
      const payload = {
        ...form,
        features: featuresText.split('\n').map((s) => s.trim()).filter(Boolean),
      }
      const saved = product
        ? await updateProduct(product.id, payload)
        : await createProduct(payload)
      onSaved(saved)
      onClose()
    } catch (err) {
      setError(err.message || 'Erreur lors de l’enregistrement.')
    } finally {
      setSaving(false)
    }
  }

  async function addChangelog() {
    if (!clVersion.trim() || !clDesc.trim()) return
    const saved = await saveChangelogEntry({
      product_id: product ? product.id : undefined,
      version: clVersion.trim(),
      description: clDesc.trim(),
      released_at: new Date().toISOString().slice(0, 10),
    })
    setChangelog((c) => [saved, ...c])
    setClVersion('')
    setClDesc('')
  }

  async function removeChangelog(id) {
    await deleteChangelogEntry(id)
    setChangelog((c) => c.filter((x) => x.id !== id))
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={product ? `Modifier — ${product.name}` : 'Ajouter un produit'}
      footer={
        <>
          <button type="button" onClick={onClose} className="btn-ghost">Annuler</button>
          <button type="submit" form="product-form" disabled={saving} className="btn-primary disabled:opacity-60">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </>
      }
    >
      <form id="product-form" onSubmit={onSubmit} className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Nom du produit">
            <input required value={form.name} onChange={set('name')} className="input" placeholder="Ex : i-SOA Shop Game" />
          </Field>
          <Field label="Slug (URL)" hint="Utilisé dans l’adresse /produit/slug">
            <input value={form.slug} onChange={set('slug')} className="input" placeholder="i-soa-shop-game" />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Type">
            <select value={form.type} onChange={set('type')} className="input">
              {TYPES.map((t) => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Catégorie">
            <input value={form.category} onChange={set('category')} className="input" placeholder="Ex : Boutique & Recharges" />
          </Field>
        </div>

        <Field label="Description courte">
          <input value={form.short_description} onChange={set('short_description')} className="input" placeholder="Une phrase qui accroche…" />
        </Field>

        <Field label="Description complète">
          <textarea rows={5} value={form.long_description} onChange={set('long_description')} className="input resize-none" placeholder="Description détaillée, un paragraphe par ligne…" />
        </Field>

        <Field label="Fonctionnalités clés" hint="Une fonctionnalité par ligne.">
          <textarea rows={4} value={featuresText} onChange={(e) => setFeaturesText(e.target.value)} className="input resize-none" />
        </Field>

        <Field label="Icône">
          <input type="file" accept="image/*" onChange={handleIcon} className="input" />
          {(form.icon_url || product?.icon_url) && (
            <img src={product?.icon_url || form.icon_url} alt="" className="mt-2 h-16 w-16 rounded-xl shadow-soft" />
          )}
        </Field>

        <Field label="Captures d’écran" hint="Jusqu’à 8 images. La première sert d’aperçu.">
          <input type="file" accept="image/*" multiple onChange={handleScreenshots} className="input" />
          {form.screenshots.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {form.screenshots.map((s, i) => (
                <div key={i} className="relative">
                  <img src={s} alt="" className="h-16 w-24 rounded-lg object-cover" />
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, screenshots: f.screenshots.filter((_, j) => j !== i) }))}
                    className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-600 text-[10px] text-white"
                  >✕</button>
                </div>
              ))}
            </div>
          )}
        </Field>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Lien du site">
            <input value={form.site_url} onChange={set('site_url')} className="input" placeholder="https://…" />
          </Field>
          <Field label="Lien APK">
            <input value={form.apk_url} onChange={set('apk_url')} className="input" placeholder="https://…..apk" />
          </Field>
          <Field label="Vidéo démo (URL)">
            <input value={form.demo_video_url} onChange={set('demo_video_url')} className="input" placeholder="https://…" />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Statut">
            <select value={form.status} onChange={set('status')} className="input">
              <option value="published">Publié (visible sur la vitrine)</option>
              <option value="draft">Brouillon (masqué)</option>
              <option value="archived">Archivé</option>
            </select>
          </Field>
          <div className="flex items-end">
            <label className="flex items-center gap-2 text-sm font-medium text-slate-700 py-2.5 dark:text-slate-200">
              <input
                type="checkbox"
                checked={form.is_featured}
                onChange={(e) => setForm((f) => ({ ...f, is_featured: e.target.checked }))}
                className="h-4 w-4 rounded border-slate-300 text-brand-600"
              />
              Mettre en vedette sur l’accueil
            </label>
          </div>
        </div>

        {/* Changelog section (only when editing existing product) */}
        {product && (
          <Card title="Nouveautés / Versions">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Version">
                <input value={clVersion} onChange={(e) => setClVersion(e.target.value)} className="input" placeholder="1.0.0" />
              </Field>
              <Field label="Description">
                <input value={clDesc} onChange={(e) => setClDesc(e.target.value)} className="input" placeholder="Quoi de neuf ?" />
              </Field>
            </div>
            <button type="button" onClick={addChangelog} className="mt-3 btn-ghost text-xs">+ Ajouter la version</button>
            {changelog.length > 0 && (
              <ul className="mt-4 space-y-2">
                {changelog.map((c) => (
                  <li key={c.id} className="flex items-center gap-3 rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800">
                    <span className="rounded-md bg-brand-50 px-2 py-0.5 text-xs font-bold text-brand-600 dark:bg-brand-950 dark:text-brand-300">v{c.version}</span>
                    <span className="flex-1 text-slate-600 dark:text-slate-300">{c.description}</span>
                    <button type="button" onClick={() => removeChangelog(c.id)} className="text-rose-500 hover:text-rose-700">✕</button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        )}

        {error && (
          <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-medium text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">{error}</p>
        )}
      </form>
    </Modal>
  )
}
