import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Logo from '../components/Logo'
import { getAboutContent, getProducts } from '../lib/api'

function Stat({ value, label }) {
  return (
    <div className="text-center">
      <p className="font-display text-4xl font-extrabold text-brand-600 dark:text-brand-400">{value}</p>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  )
}

export default function About() {
  const [about, setAbout] = useState(null)
  const [productCount, setProductCount] = useState(null)

  useEffect(() => {
    getAboutContent().then(setAbout).catch(() => setAbout(null))
    getProducts({ includeDrafts: false }).then((p) => setProductCount(p.length)).catch(() => {})
  }, [])

  const a = about || {
    intro: 'i-SOA DigiLab est la branche de recherche et développement informatique du groupe i-SOAMADA Company.',
    mission: '',
    vision: '',
    values: ['Innovation', 'Qualité', 'Sécurité', 'Transparence'],
  }

  const branches = [
    {
      name: 'i-SOAMADA',
      role: 'Société mère',
      desc: 'L’entreprise mère et propriétaire de la marque i-SOA. Elle regroupe les différentes branches opérationnelles du groupe.',
      tone: 'from-brand-400 to-brand-600',
    },
    {
      name: 'i-SOA DigiLab',
      role: 'Recherche & Développement',
      desc: 'La branche qui recherche, conçoit et développe les produits technologiques présentés sur cette vitrine. C’est l’atelier créatif du groupe.',
      tone: 'from-indigo-400 to-accent-500',
      highlight: true,
    },
    {
      name: 'i-SOA CybHa',
      role: 'Sécurité & Protection',
      desc: 'La branche en charge de la protection et de la sécurité de tous les clients. Elle sécurise les produits et les environnements du groupe.',
      tone: 'from-emerald-400 to-teal-600',
    },
  ]

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-b from-indigo-50 via-white to-slate-50 dark:border-slate-800 dark:from-brand-950/40 dark:via-slate-950 dark:to-slate-950">
        <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full bg-indigo-400/20 blur-3xl" />
        <div className="relative mx-auto max-w-4xl px-4 py-16 text-center md:py-20">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl shadow-soft-lg">
            <Logo size={72} />
          </div>
          <p className="mt-6 text-xs font-bold uppercase tracking-widest text-brand-600 dark:text-brand-400">
            À propos de i-SOA DigiLab
          </p>
          <h1 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-slate-900 md:text-5xl dark:text-white">
            Le laboratoire numérique <span className="bg-gradient-to-r from-brand-500 to-accent-500 bg-clip-text text-transparent">i-SOA DigiLab</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-slate-600 dark:text-slate-300">
            {a.intro}
          </p>
        </div>
      </section>

      {/* Organisation / branches */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-center font-display text-2xl font-bold text-slate-900 dark:text-white">
          Le groupe i-SOAMADA en trois branches
        </h2>
        <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-500 dark:text-slate-400">
          i-SOAMADA se structure autour de trois métiers complémentaires, tous au service des clients.
        </p>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {branches.map((b) => (
            <div
              key={b.name}
              className={`card-hover overflow-hidden rounded-2xl border bg-white shadow-soft dark:bg-slate-900 ${
                b.highlight
                  ? 'border-brand-300 dark:border-brand-800'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className={`h-2 bg-gradient-to-r ${b.tone}`} />
              <div className="p-6">
                <p className="font-display text-lg font-bold text-slate-900 dark:text-white">{b.name}</p>
                <p className={`mt-1 text-xs font-semibold uppercase tracking-wider ${b.highlight ? 'text-brand-500' : 'text-slate-400'}`}>
                  {b.role}
                </p>
                <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-7 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-100 text-brand-600 dark:bg-brand-900 dark:text-brand-300">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="M1.8 12h8.7M13.5 12h8.7"/></svg>
                </span>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Notre mission</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                {a.mission || 'Créer des produits numériques utiles, performants et accessibles, conçus de bout en bout par notre équipe.'}
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-7 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent-100 text-accent-600 dark:bg-accent-900/40 dark:text-accent-400">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>
                </span>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Notre vision</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                {a.vision || 'Devenir la référence du produit numérique fait maison, moderne, fiable et sécurisé.'}
              </p>
            </div>
          </div>

          {/* Values */}
          <div className="mt-10">
            <h3 className="text-center font-display text-xl font-bold text-slate-900 dark:text-white">Nos valeurs</h3>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              {(a.values || []).map((v) => (
                <span key={v} className="rounded-full border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200">
                  {v}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Key figures */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-center font-display text-2xl font-bold text-slate-900 dark:text-white">Chiffres clés</h2>
        <div className="mt-8 grid grid-cols-2 gap-6 md:grid-cols-4">
          <Stat value={`${productCount ?? '—'}`} label="Produit(s) en vitrine" />
          <Stat value="3" label="Branches métiers" />
          <Stat value="100%" label="Créé en interne" />
          <Stat value="24/7" label="Protégé par CybHa" />
        </div>
        <div className="mt-10 text-center">
          <Link to="/contact" className="btn-primary">Travailler avec nous</Link>
        </div>
      </section>
    </div>
  )
}
