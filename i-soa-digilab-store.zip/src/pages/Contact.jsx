import { useState } from 'react'
import { sendMessage } from '../lib/api'

const SUBJECTS = [
  'Demande de renseignement',
  'Signalement / support produit',
  'Collaboration / projet',
  'Autre',
]

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: SUBJECTS[0], message: '' })
  const [status, setStatus] = useState('idle') // idle | sending | ok | error
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  async function onSubmit(e) {
    e.preventDefault()
    setStatus('sending')
    try {
      await sendMessage(form)
      setStatus('ok')
      setForm({ name: '', email: '', subject: SUBJECTS[0], message: '' })
    } catch {
      setStatus('error')
    }
  }

  return (
    <div>
      <section className="border-b border-slate-200 bg-gradient-to-b from-brand-50 via-white to-slate-50 dark:border-slate-800 dark:from-brand-950/40 dark:via-slate-950 dark:to-slate-950">
        <div className="mx-auto max-w-6xl px-4 py-14 text-center">
          <p className="text-xs font-bold uppercase tracking-widest text-brand-600 dark:text-brand-400">Contact & Collaboration</p>
          <h1 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-slate-900 md:text-4xl dark:text-white">
            Parlons de votre idée
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-slate-600 dark:text-slate-300">
            Une question sur un produit ? Un projet à co-développer ? Écrivez-nous : nos équipes
            i-SOA DigiLab et i-SOA CybHa sont à votre écoute.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-12 lg:grid-cols-5">
        {/* Form */}
        <div className="lg:col-span-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft dark:border-slate-800 dark:bg-slate-900 md:p-8">
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">Envoyer un message</h2>
            <form onSubmit={onSubmit} className="mt-5 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label">Nom</label>
                  <input required value={form.name} onChange={set('name')} className="input" placeholder="Votre nom" />
                </div>
                <div>
                  <label className="label">E-mail</label>
                  <input required type="email" value={form.email} onChange={set('email')} className="input" placeholder="vous@exemple.com" />
                </div>
              </div>
              <div>
                <label className="label">Sujet</label>
                <select value={form.subject} onChange={set('subject')} className="input">
                  {SUBJECTS.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Message</label>
                <textarea required rows={5} value={form.message} onChange={set('message')} className="input resize-none" placeholder="Décrivez votre demande…" />
              </div>

              <button type="submit" disabled={status === 'sending'} className="btn-primary w-full disabled:opacity-60">
                {status === 'sending' ? 'Envoi en cours…' : 'Envoyer le message'}
              </button>

              {status === 'ok' && (
                <p className="rounded-xl bg-emerald-50 px-4 py-2.5 text-sm font-medium text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
                  ✅ Merci ! Votre message a bien été envoyé. Nous vous répondrons rapidement.
                </p>
              )}
              {status === 'error' && (
                <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-medium text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">
                  Une erreur est survenue. Veuillez réessayer.
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Collaboration + links */}
        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-2xl border border-brand-200 bg-gradient-to-br from-brand-50 to-white p-6 dark:border-brand-900 dark:from-brand-950/50 dark:to-slate-900">
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">💡 Vous avez un projet ? Collaborons</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              i-SOA DigiLab étudie les collaborations avec des porteurs de projets sérieux. Vous avez
              une idée d’application ou de site ? Remplissez le formulaire, choisissez le sujet
              « Collaboration / projet » et notre équipe vous recontactera.
            </p>
            <ul className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2">🛠 <span>Prototypage & développement</span></li>
              <li className="flex items-center gap-2">🎨 <span>Conception de produits numériques</span></li>
              <li className="flex items-center gap-2">🔒 <span>Sécurisation par i-SOA CybHa</span></li>
            </ul>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Nous joindre</h3>
            <div className="mt-4 space-y-3 text-sm">
              <a href="mailto:isoadigilabmailaka@gmail.com" className="flex items-center gap-3 text-slate-600 hover:text-brand-500 dark:text-slate-300">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-100 text-brand-600 dark:bg-brand-900 dark:text-brand-300">✉️</span>
                isoadigilabmailaka@gmail.com
              </a>
              <a href="#" className="flex items-center gap-3 text-slate-600 hover:text-brand-500 dark:text-slate-300">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300">💬</span>
                WhatsApp Business
              </a>
              <a href="#" className="flex items-center gap-3 text-slate-600 hover:text-brand-500 dark:text-slate-300">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600 dark:bg-indigo-900/40 dark:text-indigo-300">📱</span>
                Réseaux sociaux (à venir)
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
