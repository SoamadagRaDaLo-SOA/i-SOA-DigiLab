import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import ProductCard from '../components/ProductCard'
import { getProducts } from '../lib/api'
import { TYPE_LABELS } from '../lib/seed'

const FILTERS = [
  { key: 'all', label: 'Toutes' },
  { key: 'app', label: 'App' },
  { key: 'site', label: 'Site Web' },
  { key: 'app_site', label: 'App + Site Web' },
  { key: 'demo', label: 'Démo / Réalisation' },
]

export default function Home() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [query, setQuery] = useState('')

  useEffect(() => {
    getProducts({ includeDrafts: false })
      .then(setProducts)
      .catch(() => setProducts([]))
      .finally(() => setLoading(false))
  }, [])

  const featured = useMemo(() => products.filter((p) => p.is_featured), [products])

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesFilter = filter === 'all' || p.type === filter
      const q = query.trim().toLowerCase()
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.short_description || '').toLowerCase().includes(q) ||
        (p.category || '').toLowerCase().includes(q)
      return matchesFilter && matchesQuery
    })
  }, [products, filter, query])

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-b from-brand-50 via-white to-slate-50 dark:border-slate-800 dark:from-brand-950/40 dark:via-slate-950 dark:to-slate-950">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-400/20 blur-3xl dark:bg-brand-600/20" />
        <div className="pointer-events-none absolute -left-24 bottom-0 h-80 w-80 rounded-full bg-accent-400/20 blur-3xl" />
        <div className="relative mx-auto max-w-6xl px-4 py-16 md:py-24">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/70 px-4 py-1.5 text-xs font-semibold text-brand-600 dark:border-brand-900 dark:bg-slate-900/60 dark:text-brand-300">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75"></span>
              <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500"></span>
            </span>
            Vitrine exclusive · Produits <span className="font-bold">i-SOA DigiLab</span>
          </p>
          <h1 className="max-w-3xl font-display text-4xl font-extrabold leading-tight tracking-tight text-slate-900 md:text-6xl dark:text-white">
            Des produits numériques, <span className="bg-gradient-to-r from-brand-500 to-accent-500 bg-clip-text text-transparent">pensés et créés</span> par i-SOA DigiLab
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-slate-600 dark:text-slate-300">
            Consultez les applications, sites et solutions technologiques développés en interne par
            la branche R&amp;D du groupe <span className="font-semibold text-slate-800 dark:text-white">i-SOAMADA</span>.
            Tout ce que vous voyez ici est l’œuvre de notre équipe — rien ne provient de tiers.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Link to="/a-propos" className="btn-primary">Découvrir i-SOA DigiLab</Link>
            <Link to="/contact" className="btn-ghost">Proposer une collaboration</Link>
          </div>

          {/* Search bar */}
          <div className="relative mt-10 max-w-2xl">
            <svg className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher un produit…"
              className="w-full rounded-2xl border border-slate-200 bg-white py-3.5 pl-12 pr-4 text-sm shadow-soft outline-none transition focus:border-brand-500 focus:ring-2 focus:ring-brand-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          {featured.length > 0 && (
            <div className="mt-6 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-semibold uppercase tracking-wide">À la une</span>
              {featured.map((p) => (
                <Link
                  key={p.id}
                  to={`/produit/${p.slug}`}
                  className="rounded-full border border-slate-200 bg-white px-3 py-1 font-medium text-slate-600 transition hover:border-brand-400 hover:text-brand-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
                >
                  {p.name}
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CATALOGUE */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 md:text-3xl dark:text-white">
              Catalogue des produits
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {products.length} création{products.length > 1 ? 's' : ''} exclusive{products.length > 1 ? 's' : ''} d’i-SOA DigiLab
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-6 flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                filter === f.key
                  ? 'bg-brand-600 text-white shadow-soft'
                  : 'border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {f.label}
              {f.key !== 'all' && (
                <span className="ml-1 text-xs opacity-70">
                  ({products.filter((p) => p.type === f.key).length})
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Grid */}
        {loading ? (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-72 animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-800" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-12 rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-700 dark:bg-slate-900">
            <p className="text-4xl">🔍</p>
            <h3 className="mt-3 font-display text-lg font-semibold text-slate-800 dark:text-white">Aucun produit trouvé</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Essayez un autre terme ou une autre catégorie.
            </p>
          </div>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* CONTEXT STRIP */}
      <section className="border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
          {[
            { t: 'i-SOAMADA', d: 'L’entreprise mère, propriétaire des marques i-SOA.' },
            { t: 'i-SOA DigiLab', d: 'La branche Recherche & Développement qui crée ces produits.' },
            { t: 'i-SOA CybHa', d: 'La branche sécurité, qui protège tous nos clients.' },
          ].map((b) => (
            <div key={b.t} className="rounded-2xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-900">
              <p className="font-display text-sm font-bold uppercase tracking-wide text-brand-600 dark:text-brand-400">{b.t}</p>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{b.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
