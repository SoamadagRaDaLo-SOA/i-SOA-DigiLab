import { Link } from 'react-router-dom'
import Logo from './Logo'

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <Logo />
              <span className="font-display text-lg font-bold text-slate-900 dark:text-white">
                i-SOA DigiLab <span className="text-slate-400">Store</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-500 dark:text-slate-400">
              La vitrine officielle des produits technologiques créés par{' '}
              <span className="font-semibold text-slate-600 dark:text-slate-300">i-SOA DigiLab</span>,
              la branche recherche &amp; développement de{' '}
              <span className="font-semibold text-slate-600 dark:text-slate-300">i-SOAMADA</span>.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-200">Navigation</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li><Link className="hover:text-brand-500" to="/">Accueil</Link></li>
              <li><Link className="hover:text-brand-500" to="/a-propos">À propos de i-SOA DigiLab</Link></li>
              <li><Link className="hover:text-brand-500" to="/contact">Contact & Collaboration</Link></li>
              <li><Link className="hover:text-brand-500" to="/admin">Espace admin</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-200">Le Groupe i-SOA</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li><span className="hover:text-brand-500 cursor-default">i-SOAMADA (société mère)</span></li>
              <li><span className="hover:text-brand-500 cursor-default">i-SOA DigiLab (R&amp;D)</span></li>
              <li><span className="hover:text-brand-500 cursor-default">i-SOA CybHa (sécurité)</span></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-6 text-xs text-slate-400 md:flex-row dark:border-slate-800">
          <p>© {new Date().getFullYear()} i-SOAMADA Company — i-SOA DigiLab. Tous droits réservés.</p>
          <p>Produits exclusifs de i-SOA DigiLab · Protégés par i-SOA CybHa.</p>
        </div>
      </div>
    </footer>
  )
}
