export default function Logo({ size = 38 }) {
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} role="img" aria-label="i-SOA DigiLab">
      <defs>
        <linearGradient id="lg-a" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3382ff" />
          <stop offset="0.6" stopColor="#1c63f5" />
          <stop offset="1" stopColor="#7c3aed" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="58" height="58" rx="16" fill="url(#lg-a)" />
      <g transform="translate(32 32)">
        <rect x="-17" y="-17" width="34" height="34" rx="9" fill="none" stroke="#ffffff" strokeWidth="2.6" opacity="0.95" />
        <rect x="-8" y="-8" width="16" height="16" rx="4" fill="#ffffff" />
        <circle cx="0" cy="0" r="3" fill="#1c63f5" />
        <path d="M0 -23 v4 M0 19 v4 M-23 0 h4 M19 0 h4" stroke="#ffffff" strokeWidth="2.6" strokeLinecap="round" opacity="0.95" />
      </g>
    </svg>
  )
}
