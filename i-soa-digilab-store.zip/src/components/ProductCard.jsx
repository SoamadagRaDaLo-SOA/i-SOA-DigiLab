import { Link } from 'react-router-dom'
import TypeBadge from './TypeBadge'
import { TYPE_LABELS } from '../lib/seed'

export default function ProductCard({ product }) {
  return (
    <Link
      to={`/produit/${product.slug}`}
      className="card-hover group block overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-slate-800 dark:bg-slate-900"
    >
      <div className="relative h-32 w-full overflow-hidden bg-gradient-to-br from-brand-500/15 via-slate-100 to-slate-200 dark:from-brand-900/40 dark:via-slate-800 dark:to-slate-900">
        {/* decorative grid */}
        <svg className="absolute inset-0 h-full w-full opacity-40" aria-hidden="true">
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M20 0H0V20" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-brand-300 dark:text-brand-700" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
        {product.icon_url ? (
          <img
            src={product.icon_url}
            alt=""
            className="absolute left-1/2 top-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-2xl shadow-soft-lg transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="absolute left-1/2 top-1/2 flex h-20 w-20 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-2xl bg-brand-500 text-2xl font-bold text-white">
            {product.name?.[0]}
          </div>
        )}
        {product.is_featured && (
          <span className="absolute right-3 top-3 rounded-full bg-amber-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-amber-700 dark:bg-amber-900/50 dark:text-amber-300">
            ★ À la une
          </span>
        )}
      </div>

      <div className="p-5">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-base font-bold leading-snug text-slate-900 dark:text-white">
            {product.name}
          </h3>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
          <TypeBadge type={product.type} />
          {product.category && (
            <span className="rounded-full bg-slate-100 px-2.5 py-1 font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
              {product.category}
            </span>
          )}
        </div>
        <p className="mt-3 line-clamp-2 text-sm text-slate-500 dark:text-slate-400">
          {product.short_description}
        </p>
        <div className="mt-4 flex items-center justify-between text-xs font-semibold text-brand-600 dark:text-brand-400">
          <span>Voir le produit</span>
          <span className="transition-transform group-hover:translate-x-1">→</span>
        </div>
      </div>
    </Link>
  )
}
