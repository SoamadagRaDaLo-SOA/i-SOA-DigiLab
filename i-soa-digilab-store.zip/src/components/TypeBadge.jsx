import { TYPE_LABELS } from '../lib/seed'

const STYLES = {
  app: 'bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300',
  site: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
  app_site: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300',
  demo: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
}

export default function TypeBadge({ type }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${STYLES[type] || STYLES.app}`}
    >
      {TYPE_LABELS[type] || type}
    </span>
  )
}
