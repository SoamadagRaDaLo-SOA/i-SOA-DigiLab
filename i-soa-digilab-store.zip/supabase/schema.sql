-- =====================================================================
--  i-SOA DigiLab Store — Supabase schema
--  Run this in the Supabase SQL editor (or via `supabase db push`).
--
--  SECURITY MODEL:
--   • Authentication via Google OAuth ONLY (email/password disabled).
--   • ONLY the Google account isoadigilabmailaka@gmail.com is allowed
--     to read/write admin data. This is enforced in Row Level Security
--     (server side), not just in the UI.
--   • No public sign-up. No third-party publishing.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) NOTES / SECRETS
-- ---------------------------------------------------------------------
-- * In Supabase Auth, disable Email/Password provider (leave Google ON).
--   Dashboard → Authentication → Providers.
-- * Under Authentication → URL Configuration, set the Site URL and add
--   the redirect URL for this app.
-- * Add the only allowed admin e-mail as an authorised sign-in.

-- ---------------------------------------------------------------------
-- 2) Helper: is this user the single authorised admin?
-- ---------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(auth.email(), '') = 'isoadigilabmailaka@gmail.com';
$$;

-- ---------------------------------------------------------------------
-- 3) TABLES
-- ---------------------------------------------------------------------

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  type text not null check (type in ('app','site','app_site','demo')),
  category text,
  short_description text,
  long_description text,
  icon_url text,
  screenshots jsonb not null default '[]'::jsonb,
  demo_video_url text,
  site_url text,
  apk_url text,
  features jsonb not null default '[]'::jsonb,
  status text not null default 'published' check (status in ('published','draft','archived')),
  is_featured boolean not null default false,
  views bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists products_slug_idx on public.products (slug);
create index if not exists products_type_idx on public.products (type);
create index if not exists products_status_idx on public.products (status);

create table if not exists public.product_changelog (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  version text not null,
  description text not null,
  released_at date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists changelog_product_idx on public.product_changelog (product_id);

create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  subject text,
  message text not null,
  status text not null default 'new' check (status in ('new','read','handled')),
  created_at timestamptz not null default now()
);
create index if not exists messages_status_idx on public.contact_messages (status);

create table if not exists public.about_content (
  id uuid primary key default gen_random_uuid(),
  intro text,
  mission text,
  vision text,
  values jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
-- keep a single content row
insert into public.about_content (id, intro, mission, vision, values)
values (
  '00000000-0000-0000-0000-000000000001',
  'i-SOA DigiLab est la branche de recherche et développement informatique du groupe i-SOAMADA Company.',
  'Créer des produits numériques utiles, performants et accessibles, conçus de bout en bout par notre équipe.',
  'Devenir la référence du produit numérique fait maison, moderne, fiable et sécurisé.',
  '["Innovation","Qualité","Sécurité","Transparence"]'::jsonb
) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 4) trigger: updated_at / view counter
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists products_set_updated on public.products;
create trigger products_set_updated
  before update on public.products
  for each row execute function public.set_updated_at();

drop trigger if exists about_set_updated on public.about_content;
create trigger about_set_updated
  before update on public.about_content
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- 5) ROW LEVEL SECURITY — the core of the security model.
--    Public (anon) may read PUBLISHED products and WRITE contact messages.
--    Only the authorised admin may insert/update/delete products,
--    changelog, messages, and about content. All enforcement is server side.
-- ---------------------------------------------------------------------

alter table public.products enable row level security;
alter table public.product_changelog enable row level security;
alter table public.contact_messages enable row level security;
alter table public.about_content enable row level security;

-- PRODUCTS ------------------------------------------------------------------
-- Public read of published products only.
drop policy if exists products_select_published on public.products;
create policy products_select_published on public.products
  for select to anon, authenticated
  using (status = 'published');

-- Public read of published products even for admin dashboard demo is via anon,
-- but admin needs to see drafts too. A dedicated policy grants admin full read.
drop policy if exists products_select_admin on public.products;
create policy products_select_admin on public.products
  for select to authenticated
  using (public.is_admin());

-- Inserts: only admin.
drop policy if exists products_insert_admin on public.products;
create policy products_insert_admin on public.products
  for insert to authenticated
  with check (public.is_admin());

-- Updates: only admin.
drop policy if exists products_update_admin on public.products;
create policy products_update_admin on public.products
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Deletes: only admin.
drop policy if exists products_delete_admin on public.products;
create policy products_delete_admin on public.products
  for delete to authenticated
  using (public.is_admin());

-- PRODUCT_CHANGELOG -----------------------------------------------------------
drop policy if exists changelog_select_published on public.product_changelog;
create policy changelog_select_published on public.product_changelog
  for select to anon, authenticated
  using (true); -- only reachable via published products in the app

drop policy if exists changelog_insert_admin on public.product_changelog;
create policy changelog_insert_admin on public.product_changelog
  for insert to authenticated with check (public.is_admin());
drop policy if exists changelog_update_admin on public.product_changelog;
create policy changelog_update_admin on public.product_changelog
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists changelog_delete_admin on public.product_changelog;
create policy changelog_delete_admin on public.product_changelog
  for delete to authenticated using (public.is_admin());

-- CONTACT_MESSAGES ------------------------------------------------------------
-- Public visitors (anon) can insert a message.
drop policy if exists messages_insert_public on public.contact_messages;
create policy messages_insert_public on public.contact_messages
  for insert to anon, authenticated
  with check (true);

-- Reading/treating messages: admin only.
drop policy if exists messages_select_admin on public.contact_messages;
create policy messages_select_admin on public.contact_messages
  for select to authenticated using (public.is_admin());
drop policy if exists messages_update_admin on public.contact_messages;
create policy messages_update_admin on public.contact_messages
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists messages_delete_admin on public.contact_messages;
create policy messages_delete_admin on public.contact_messages
  for delete to authenticated using (public.is_admin());

-- ABOUT_CONTENT --------------------------------------------------------------
drop policy if exists about_select_public on public.about_content;
create policy about_select_public on public.about_content
  for select to anon, authenticated using (true);
drop policy if exists about_update_admin on public.about_content;
create policy about_update_admin on public.about_content
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists about_insert_admin on public.about_content;
create policy about_insert_admin on public.about_content
  for insert to authenticated with check (public.is_admin());

-- ---------------------------------------------------------------------
-- 6) Storage bucket for admin uploads (icons, screenshots, videos).
--    Public read, admin-only write.
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('assets', 'assets', true)
on conflict (id) do nothing;

drop policy if exists "assets public read" on storage.objects;
create policy "assets public read" on storage.objects
  for select using (bucket_id = 'assets');

drop policy if exists "assets admin write" on storage.objects;
create policy "assets admin write" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'assets' and public.is_admin());

drop policy if exists "assets admin update" on storage.objects;
create policy "assets admin update" on storage.objects
  for update to authenticated
  using (bucket_id = 'assets' and public.is_admin());

drop policy if exists "assets admin delete" on storage.objects;
create policy "assets admin delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'assets' and public.is_admin());

-- ---------------------------------------------------------------------
-- 7) OPTIONAL: seed the launch catalogue.
--    Uncomment to load the three launch products. (Images are placeholders;
--    replace icon_url/screenshots with real URLs via the admin UI.)
-- ---------------------------------------------------------------------
-- insert into public.products (name, slug, type, category, short_description,
--   long_description, status, is_featured) values
-- ('i-SOA Shop Game (iSOA Diamond Shop)','i-soa-shop-game','app_site',
--  'Boutique & Recharges',
--  'Achetez et rechargez des diamants pour vos jeux préférés.',
--  'Boutique officielle i-SOA DigiLab pour la recharge de diamants. Démarre avec Free Fire, extension à d''autres jeux prévue.', 'published', true),
-- ('intelli-SOA BOT','intelli-soa-bot','app_site','Intelligence Artificielle',
--  'Plateforme de chat IA avec génération de code, aperçu live et terminal intégré.',
--  'Assistant conversationnel i-SOA DigiLab : chat IA, génération de code, terminal et preview.', 'published', true),
-- ('i-SOA CO','i-soa-co','app_site','Réseau social',
--  'Le réseau social nouvelle génération : messagerie, publications, stories & comptes pro.',
--  'Réseau social i-SOA DigiLab : messagerie, fil, stories et comptes professionnels.', 'published', true);
